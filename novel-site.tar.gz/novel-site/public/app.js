(() => {
  const audioA = document.getElementById('audio-a');
  const audioB = document.getElementById('audio-b');
  const button = document.getElementById('music-toggle');
  const label = document.getElementById('music-label');
  if (!audioA || !audioB) return;

  let active = audioA, standby = audioB, currentUrl = '';
  let playingWanted = false;
  let fadeTimer = null;
  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const fadeDefault = 1800;

  function setLabel(text) { if (label) label.textContent = text || 'Музыка'; }
  function fadeOut(audio, ms) {
    const start = audio.volume;
    const started = performance.now();
    return new Promise(resolve => {
      const tick = now => {
        const t = Math.min(1, (now - started) / ms);
        audio.volume = start * (1 - t);
        if (t < 1) requestAnimationFrame(tick); else { audio.pause(); audio.currentTime = 0; resolve(); }
      };
      requestAnimationFrame(tick);
    });
  }
  function fadeIn(audio, ms) {
    const started = performance.now();
    audio.volume = 0;
    return new Promise(resolve => {
      const tick = now => {
        const t = Math.min(1, (now - started) / ms);
        audio.volume = t;
        if (t < 1) requestAnimationFrame(tick); else resolve();
      };
      requestAnimationFrame(tick);
    });
  }
  async function changeMusic(url, fadeMs, name='Музыка') {
    url = (url || '').trim();
    if (url === currentUrl) return;
    currentUrl = url;
    if (fadeTimer) clearTimeout(fadeTimer);
    const ms = reduceMotion ? 0 : Math.max(300, Number(fadeMs || fadeDefault));
    setLabel(url ? name : 'Музыка выключена');
    if (!url) {
      await fadeOut(active, ms);
      return;
    }
    standby.pause(); standby.src = url; standby.load(); standby.loop = true;
    try { await standby.play(); if (button) button.textContent = '❚❚'; } catch (e) { playingWanted = true; return; }
    const old = active;
    active = standby; standby = old;
    if (!ms) { active.volume = 1; old.pause(); old.currentTime = 0; }
    else {
      active.volume = 0;
      Promise.all([fadeIn(active, ms), fadeOut(old, ms)]).catch(() => {});
    }
  }

  const sections = [...document.querySelectorAll('.section')];
  let lastSeen = null;
  const observer = new IntersectionObserver(entries => {
    const visible = entries.filter(e => e.isIntersecting).sort((a,b) => b.intersectionRatio - a.intersectionRatio);
    if (!visible.length) return;
    const section = visible[0].target;
    if (section === lastSeen) return;
    lastSeen = section;
    changeMusic(section.dataset.music, section.dataset.fade, section.dataset.musicName || 'Музыка');
  }, { rootMargin: '-28% 0px -45% 0px', threshold: [0, .2, .5, .8] });
  sections.forEach(s => observer.observe(s));

  button?.addEventListener('click', async () => {
    if (active.paused) {
      playingWanted = true;
      try { await active.play(); active.loop = true; active.volume = 1; button.textContent = '❚❚'; } catch {}
    } else {
      playingWanted = false; active.pause(); button.textContent = '▶';
    }
  });
  window.addEventListener('pointerdown', async () => {
    if (!playingWanted && active.src && active.paused) return;
    if (playingWanted && active.paused) { try { await active.play(); active.loop = true; if (button) button.textContent = '❚❚'; } catch {} }
  }, { once: true });
})();
